package com.javaBase.intiliaser;

import java.util.Properties;

import org.hibernate.cfg.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com")
@EnableWebMvc
public class AppConfig {
	
	@Bean
	public InternalResourceViewResolver view() {
		InternalResourceViewResolver itvr=new InternalResourceViewResolver();
		itvr.setSuffix(".jsp");
		return itvr;
	}
	
	@Bean
	public DriverManagerDataSource ds() {
		
		DriverManagerDataSource ds= new DriverManagerDataSource();
		
		ds.setDriverClassName("com.mysql.jdbc.Driver");
//		ds.setUrl(url);
//		ds.setPassword(password);
		
		return ds;
		
	}
	
	@Bean
	public LocalSessionFactoryBean ls() {
		
		LocalSessionFactoryBean ls= new LocalSessionFactoryBean();
		
		ls.setDataSource(ds());
		
		Properties p=new Properties();
		p.setProperty(Environment.DIALECT, "");
		p.setProperty(Environment.SHOW_SQL, "");
		p.setProperty(Environment.HBM2DDL_AUTO, "");
		
		ls.setHibernateProperties(p);
		
//		ls.setAnnotatedClasses(Student.class);
		ls.setPackagesToScan("com");
		return ls;
		
	}
	
	
	
	
	

}
