package com;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Test {

	public static void getAllStudent(SessionFactory sf) {

//		Select * from sTudent

		Session session = sf.openSession();

		Query<Student> query = session.createQuery("frOm Student");// class name
		List<Student> slist = query.getResultList();

		System.out.println(slist);
	}

	public static void getSname(SessionFactory sf) {

//		select sname from student where id=3

		Session session = sf.openSession();

		Query<String> query = session.createQuery("select sname from Student where sid=:id1");
		query.setParameter("id1", 3);

		String s = query.getSingleResult();
		System.out.println(s);

	}

	public static void getSnameAndMarks(SessionFactory sf) {

//		select sname,marks from Student where id=2

		Session session = sf.openSession();

		Query<Object[]> query = session.createQuery("select sname,marks from Student where sid=:id1");

		query.setParameter("id1", 2);

		Object[] obj = query.getSingleResult();
		
		System.out.println(Arrays.toString(obj));

	}
	
	public static void getMaxMarks(SessionFactory sf) {
		
//		Select max(marks) from student 
		
		Session session=sf.openSession();
		
		Query<Double> query=session.createQuery("select max(marks) from Student");
		
		Double d=query.getSingleResult();
		
		System.out.println(d);
		
	}
	
	

	public static void main(String[] args) {
		SessionFactory sf = HibernateUtil.getFactory();

//		Session session =sf.openSession();
//		
//		Student s= new Student();
//		
//		s.setSname("Prathamesh");
//		s.setMarks(28.15);
//		
//		session.save(s);
//		session.beginTransaction().commit();

//		getAllStudent(sf);
//		getSname(sf);
//		getSnameAndMarks(sf);
		getMaxMarks(sf);

	}

}
