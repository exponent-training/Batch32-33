package com;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="stu_data")
@NamedQueries({
	@NamedQuery(query = "from Student" ,name="getAllData"),
	@NamedQuery(query = "from Student where sid=:id1",name="getSingleStudent")
})

@NamedNativeQueries({
	@NamedNativeQuery(query = "select * from Stu_data" ,name="getAllDataUsingSQL",resultClass = Student.class),
	@NamedNativeQuery(query = "select * from stu_data where stu_id=?",name="getSingleStudentByUsingSQL",resultClass = Student.class)
	
})
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="stu_id")
	private int sid;
	
	private String sname;
	
	private double marks;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", marks=" + marks + "]";
	}
	
	

}
