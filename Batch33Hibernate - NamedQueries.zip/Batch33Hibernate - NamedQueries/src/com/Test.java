package com;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Test {

	public static void main(String[] args) {
		SessionFactory sf = HibernateUtil.getFactory();

		Session session = sf.openSession();

//		Student s= new Student();
//		
//		s.setSname("Pratik");
//		s.setMarks(45.68);
//		
//		session.save(s);
//		session.beginTransaction().commit();

//		Query<Student> query = session.createNamedQuery("getAllData");
//		List<Student> slist = query.getResultList();
//		System.out.println(slist);
		
//		Query<Student> query=session.createNamedQuery("getSingleStudent");
//		query.setParameter("id1", 1);
//		Student s=query.getSingleResult();
//		System.out.println(s);
		
//		Query<Student> query=session.createNamedQuery("getAllDataUsingSQL");
//		List<Student>slist=query.getResultList();
//		
//		System.out.println(slist);
		
		Query<Student> query=session.createNamedQuery("getSingleStudentByUsingSQL");
		query.setParameter(1, 2);
		
		System.out.println(query.getSingleResult());
	}

}
