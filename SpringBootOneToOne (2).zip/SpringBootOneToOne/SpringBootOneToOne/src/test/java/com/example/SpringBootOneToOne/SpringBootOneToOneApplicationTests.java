package com.example.SpringBootOneToOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOneToOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
