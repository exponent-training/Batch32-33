package com.example.SpringBootOneToOne.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringBootOneToOne.dao.PersonRepository;
import com.example.SpringBootOneToOne.model.Person;

@Service
public class ServiceImpl implements Services {
	
	@Autowired
	private PersonRepository personRepo;

	@Override
	public String savePersonData(Person person) {
		System.out.println("MSG : we are in save method in service layer");
		System.out.println("MSG : Person That retrived service "+person);
		person.getAdharCard().setDateOfRegister(new Date());
		
		personRepo.save(person);
		
		System.out.println("MSG : we are in save method completed in service layer");
		return "Successfully";
		
	}
	
	

}
