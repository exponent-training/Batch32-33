package com.example.SpringBootOneToOne.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootOneToOne.model.Person;
import com.example.SpringBootOneToOne.services.Services;

@RestController
public class HomeController {
	
	@Autowired
	private Services services;
	
	@PostMapping(value="/save")
	public String savePersonWithAdharCard(@RequestBody Person person) {
		System.out.println("MSG : we are in save method in controller");
		System.out.println("MSG : Person That retrived "+person);
		
		String msg=services.savePersonData(person);
		System.out.println("MSG : Message That retrived "+msg);
		
		return msg;
	}

}
