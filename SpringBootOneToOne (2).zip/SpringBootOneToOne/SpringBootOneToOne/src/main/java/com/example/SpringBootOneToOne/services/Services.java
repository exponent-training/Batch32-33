package com.example.SpringBootOneToOne.services;

import com.example.SpringBootOneToOne.model.Person;

public interface Services {
	
	String savePersonData(Person person);

}
