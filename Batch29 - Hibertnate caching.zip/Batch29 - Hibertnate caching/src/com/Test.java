package com;

import javax.persistence.Cache;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {

	
	public static void main(String[] args) {
		
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		Session session=sf.openSession();
		Session session1=sf.openSession();
		
		Person p=session.get(Person.class, 1);
		System.out.println(p);
		Person p2=session.get(Person.class, 2);
		
//		session.evict(p);
//		session.clear();
//		session.close();
		
		Cache c=sf.getCache();
//		c.evict(Person.class);
		c.evictAll();
		
		System.out.println("\n-----------------------------------\n");
		
		Person p1=session1.get(Person.class, 1);
		System.out.println(p1);
		Person p3=session1.get(Person.class, 2);
		
		
		
		
		
		
		
		
		
//		Person p= new Person();
//		p.setPname("Pqr");
//		
//		session.save(p);
//		session.beginTransaction().commit();
		
		
		
	}
}
