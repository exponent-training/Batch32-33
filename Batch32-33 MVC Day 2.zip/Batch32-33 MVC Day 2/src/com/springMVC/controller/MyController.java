package com.springMVC.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	@RequestMapping(value = "log")//3.0 >> 4.0 
	public String getLogin() {
		
		System.out.println("WE are here");
		
		return "success";
		
	}

}
