package com.springMVC.model;

public class Student {
	
	
}
