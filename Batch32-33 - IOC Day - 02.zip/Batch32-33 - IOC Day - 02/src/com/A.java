package com;

public class A {
	
	private int id;
	
	private String name;
	
	public A(int id) {
		System.out.println("Int");
	}
	
	public A(String s) {
		System.out.println("String");
	}

}
