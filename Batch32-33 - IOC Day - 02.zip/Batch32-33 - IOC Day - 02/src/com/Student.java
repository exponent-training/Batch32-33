package com;

public class Student {
	
	private int sid;
	
	private String sname;
	

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		System.out.println("Setter");
		this.sname = sname;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + "]";
	}

	public Student(int sid, String sname) {
		super();
		
		System.out.println("constructor called");
		this.sid = sid;
		this.sname = sname;
	}
}
