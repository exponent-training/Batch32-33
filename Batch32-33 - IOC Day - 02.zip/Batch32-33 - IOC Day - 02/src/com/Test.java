package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	
	public static void main(String[] args) {
		
		ApplicationContext apc=new ClassPathXmlApplicationContext("NewFile.xml");
		
//		Student s=(Student) apc.getBean("s");
//		System.out.println(s);
//		
//		College c=(College) apc.getBean("c");
//		System.out.println(c);
		
		A a=(A) apc.getBean("a");
		System.out.println(a);
		
	}

}
