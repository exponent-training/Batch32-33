package com.mvc.model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
public class Student {
	
	@Id
	private int sid;
	
	private String sname;
	
	@Lob
	private byte[] fileUpload;
	
	private String dob;
	
	@Temporal(value=TemporalType.TIMESTAMP)
	private Date regsiterDate;//date
	
	@Transient
	private int kk;
	
	public int getKk() {
		return kk;
	}

	public void setKk(int kk) {
		this.kk = kk;
	}

	

	public Date getRegsiterDate() {
		return regsiterDate;
	}

	public void setRegsiterDate(Date regsiterDate) {
		this.regsiterDate = regsiterDate;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public byte[] getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(byte[] fileUpload) {
		this.fileUpload = fileUpload;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", dob=" + dob + ", regsiterDate=" + regsiterDate + "]";
	}
	
	

}
