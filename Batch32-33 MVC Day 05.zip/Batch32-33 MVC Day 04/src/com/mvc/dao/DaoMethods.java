package com.mvc.dao;

import com.mvc.model.Student;

public interface DaoMethods {
	
	void addStudentData(Student s);

}
