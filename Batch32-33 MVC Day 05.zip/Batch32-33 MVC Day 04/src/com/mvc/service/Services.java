package com.mvc.service;

import com.mvc.model.Student;

public interface Services {
	
	void addStudent(Student s);

}
