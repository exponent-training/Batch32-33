package com.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mvc.model.Student;
import com.mvc.service.ServiceImpl;
import com.mvc.service.Services;

@Controller
public class MyController {
	
	@Autowired
	public Services ser;
	
	@RequestMapping(value="log")
	public String getLog(@RequestParam("uname") String userName,@RequestParam String pass) {
		
		
		System.out.println("in controller ");
		System.out.println("userName : "+userName);
		System.out.println("Password : "+pass);
		
		return "success";
	}
	
	@RequestMapping(value="/reg")
	public String registerStudent(@ModelAttribute Student s,Model m) {
		System.out.println("in controller ");
		System.out.println(s);
		
		ser.addStudent(s);
		
		m.addAttribute("stu",s);
		
		
		return "success";//model and view // key value
	}
	

}
