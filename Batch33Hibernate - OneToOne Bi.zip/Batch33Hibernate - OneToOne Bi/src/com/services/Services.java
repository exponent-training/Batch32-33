package com.services;

public interface Services {
	
	void addPersonWithAdharCard();
	
	void addAdharCardWithPerson();
	
	void getPersonWithAdharCard();
	
	void getAdharCardWithPerson();
	
	void updatePersonUsingAid();
	
	void updateAdharUsingPid();
	
	void deletePersonWithAdharCard();
	
	void deleteAdharCradWithPerson();
	
	void deleteOnlyPerson();
	
	void deleteOnlyAdharCard();

}
