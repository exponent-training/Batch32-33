package com.services;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.entity.AdharCard;
import com.entity.Person;
import com.util.HibernateUtil;

public class ServiceImpl implements Services{
	
	Scanner sc= new Scanner(System.in);
	SessionFactory sf=HibernateUtil.getFactory();

	@Override
	public void addPersonWithAdharCard() {
		
		Session session=sf.openSession();
		
		Person p= new Person();
		
		System.out.println("Enter pname : ");
		p.setPname(sc.next());
		
		AdharCard a= new AdharCard();
		
		System.out.println("Enter aname : ");
		a.setAname(sc.next());
		
		p.setAdharCard(a);
		a.setPerson(p);
		
		session.save(p);
		session.beginTransaction().commit();
		
	}

	@Override
	public void addAdharCardWithPerson() {
		
		
		
		
	}

	@Override
	public void getPersonWithAdharCard() {
		
		Session session=sf.openSession();
		System.out.println("Enter pid : ");
		Person p=session.get(Person.class, sc.nextInt());
		
		System.out.println(p);//toString()
		
	}

	@Override
	public void getAdharCardWithPerson() {
		
		
		
	}

	@Override
	public void updatePersonUsingAid() {
		
		Session session=sf.openSession();
		
		System.out.println("Enter aid : ");
		AdharCard a =session.get(AdharCard.class, sc.nextInt());
		
		Person p=a.getPerson();
		
		System.out.println("Enter pname : ");
		p.setPname(sc.next());
		
		session.update(a);
		session.beginTransaction().commit();
	}

	@Override
	public void updateAdharUsingPid() {
		
		
		
	}

	@Override
	public void deletePersonWithAdharCard() {
		
		 Session session=sf.openSession();
		 
		 System.out.println("enter pid : ");
		 Person p=session.get(Person.class, sc.nextInt());
		 
		 session.delete(p);
		 session.beginTransaction().commit();
		
	}

	@Override
	public void deleteAdharCradWithPerson() {
		
		
		
	}

	@Override
	public void deleteOnlyPerson() {
		
		Session session=sf.openSession();
		System.out.println("Enter pid : ");
		Person p=session.get(Person.class, sc.nextInt());
		
		AdharCard a=p.getAdharCard();
		p.setAdharCard(null);
		a.setPerson(null);
		
		session.delete(p);
		session.beginTransaction().commit();
		
	}

	@Override
	public void deleteOnlyAdharCard() {
		
		Session session=sf.openSession();
		System.out.println("enter aid : ");
		AdharCard a=session.get(AdharCard.class, sc.nextInt());
		
		Person p=a.getPerson();
		a.setPerson(null);
		p.setAdharCard(null);
		
		session.delete(a);
		session.beginTransaction().commit();
		
	}

}
