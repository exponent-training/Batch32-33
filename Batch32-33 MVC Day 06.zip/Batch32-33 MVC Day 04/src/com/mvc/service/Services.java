package com.mvc.service;

import java.util.List;

import com.mvc.model.Student;

public interface Services {
	
	void addStudent(Student s);
	
	List<Student> getAllStudent();

}
