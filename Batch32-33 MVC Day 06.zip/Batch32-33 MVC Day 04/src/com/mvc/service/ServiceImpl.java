package com.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mvc.dao.DaoImpl;
import com.mvc.dao.DaoMethods;
import com.mvc.model.Student;

@Service
public class ServiceImpl implements Services {
	
	@Autowired
	public DaoMethods dao;
	
	@Override
	public void addStudent(Student s) {
		// TODO Auto-generated method stub
		System.out.println("Service layer : "+s);
		dao.addStudentData(s);
		
	}

	@Override
	public List<Student> getAllStudent() {
		
		return dao.getAllStudentData();
	}

}
