package com.mvc.dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mvc.model.Student;

@Repository
public class DaoImpl implements DaoMethods{
	
	@Autowired
	public SessionFactory sf;

	@Override
	public void addStudentData(Student s) {
		
		System.out.println("Dao layer : "+s);
		Session session =sf.openSession();
		session.save(s);
		session.beginTransaction().commit();
		
	}

	@Override
	public List<Student> getAllStudentData() {
	
		Session session=sf.openSession();
		Query<Student> query=session.createQuery("from Student");
		List<Student> slist=query.getResultList();
		return slist;
	}
	
	

}
