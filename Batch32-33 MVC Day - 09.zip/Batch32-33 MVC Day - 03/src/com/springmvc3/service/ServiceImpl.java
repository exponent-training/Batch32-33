package com.springmvc3.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceImpl implements Services {

	@Override
	public void getLog() {
		System.out.println("service layer");
		
	}

}
