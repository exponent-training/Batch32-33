package com.springmvc3.service;

public interface Services {
	
	
	void getLog() ;

}
