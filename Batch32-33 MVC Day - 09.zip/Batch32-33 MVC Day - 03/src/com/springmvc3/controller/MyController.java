package com.springmvc3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc3.model.Student;
import com.springmvc3.service.Services;

@Controller
public class MyController {
	
	@Autowired
	private Services ss;
	
//	Injection
//	Property Base >> XX
//	Constructor Base  >> XX
//	Field Injection
	
	
	
	
	
	@RequestMapping(value="/log")
	public String getLog(@RequestParam("uname") String userName,@RequestParam String pass) {
		
		System.out.println("Hello there");
		System.out.println("User Name : "+userName);
		System.out.println("Password : "+pass);
		
		ss.getLog();
		
		return "success";
	}
	
	

	@RequestMapping(value = "reg")
	public String regsiterStudent(@ModelAttribute Student s) {
		
		System.out.println(s);
		
		return "success";
	}
	

}
