package com.SpringBootActuator.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@Value(value="${myApp}")
	private String msg;
	
	@RequestMapping(value="/")
	public ModelAndView start(Model m) {
		System.out.println("App Start !! "+msg);
		m.addAttribute("msg",msg);
		return new ModelAndView("index",msg,HttpStatus.OK);//mvc
	}

}
