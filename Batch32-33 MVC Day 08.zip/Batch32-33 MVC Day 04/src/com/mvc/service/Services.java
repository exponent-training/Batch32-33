package com.mvc.service;

import java.util.List;

import com.mvc.model.Student;

public interface Services {
	
	void addStudent(Student s);
	
	List<Student> getAllStudent();
	
	void deleteStudent(int id);
	
	Student getStudent(int id);
	
	void updateStudent(Student s);

}
