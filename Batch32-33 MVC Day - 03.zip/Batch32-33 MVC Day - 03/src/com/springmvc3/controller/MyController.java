package com.springmvc3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc3.model.Student;

@Controller
public class MyController {
	
	
	@RequestMapping(value="/log")
	public String getLog(@RequestParam("uname") String userName,@RequestParam String pass) {
		
		System.out.println("Hello there");
		System.out.println("User Name : "+userName);
		System.out.println("Password : "+pass);
		
		return "success";
	}
	
	@RequestMapping(value = "reg")
	public String regsiterStudent(@ModelAttribute Student s) {
		
		System.out.println(s);
		
		return "success";
	}
	

}
