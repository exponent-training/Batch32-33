package com.example.SpringBootOneToOne.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.example.SpringBootOneToOne.model.AdharCard;
import com.example.SpringBootOneToOne.model.Person;
import com.example.SpringBootOneToOne.services.Services;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class HomeController {

	@Autowired
	private Services services;

	@Autowired
	private ObjectMapper objMapper;
	

	@PostMapping(value = "/save")
	public String savePersonWithAdharCard(@RequestParam String personData, @RequestParam MultipartFile file)
			throws IOException {
		System.out.println("MSG : we are in save method in controller");
		System.out.println("Info : Json That retrived : " + personData);// json
		System.out.println("Info : File That Retrived : " + file.getOriginalFilename());

		Person person = objMapper.readValue(personData, Person.class);

		System.out.println("MSG : Person That retrived " + person);

		if (person != null) {
			person.setFileUp(file.getBytes());
			person.getAdharCard().setDateOfRegister(LocalDateTime.now());
		}
//		person.

		String msg = services.savePersonData(person);

		System.out.println("MSG : Message That retrived " + msg);
		return msg;
	}

	@DeleteMapping(value = "/delAdhar/{pid}")
	public String deleteAdharOnly(@PathVariable int pid) {
		System.out.println("Debug : we are in deleteAdharOnly method in controller");
		System.out.println("Info : Pid That retrived " + pid);
		String msg = services.deleteAdharOnly(pid);
		System.out.println("Info : Message That retrived " + msg);
		return msg;
	}

	@PostMapping(value = "/fileUpload")
	public String fileUploadMethod(@RequestPart MultipartFile file) throws IOException {
		System.out.println("Debug : we are in fileUploadMethod method in controller");
		System.out.println("Info : That retrived " + file.getOriginalFilename());

		byte[] fileup = file.getBytes();

		return "success";
	}
	
	@PostMapping(value="/test")
	public String test(@RequestParam String person,@RequestParam String person1) {
		
		System.out.println("Person1 : "+person);
		System.out.println("Person2 : "+person1);
		return "success";
	}
	
	
	@GetMapping(value="/fileGet")
	public String allAdharCardFile(HttpServletResponse response) throws IOException {
		
		System.out.println("Info : allAdharCardFile method in controller");
		
		List<AdharCard> list=services.getAllAdhar();
		
//		pdf,docx,csv >> excle
		System.out.println("Info : List That Retived : "+list);
		
		
		response.setContentType("text/csv");
		
		ICsvBeanWriter csvWriter=new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		
		String[] str= {"Aid","Aname","RegisterDate"};
		String[] str2= {"aid","aname","dateOfRegister"};
		
		
//		csvWriter.write(str, str);
		
		for(AdharCard a:list) {
			
			csvWriter.write(a,str2);
			
		}
		
		csvWriter.close();
		
		return "success";
		
	}
	
	@GetMapping(value="/getAdhar")
	public ResponseEntity<List<AdharCard>> getPerson() {//reponsebody
		
		List<AdharCard> list=services.getAllAdhar();
		
		HttpHeaders http=new HttpHeaders();
		
		http.add("info", "Data Retrive successfully");
		
//		return new ResponseEntity<List<AdharCard>>(list,http,HttpStatus.ACCEPTED);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).header("debug", "New Way").body(list);
	}
	
	@GetMapping(value="/mailSend")
	public ResponseEntity<String> mailSend(){
		
		services.sendMail();
		
		return ResponseEntity.ok().body("Success");
		
	}
	
	

	
	

}
