package com.example.SpringBootOneToOne.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.SpringBootOneToOne.dao.AdharCardRepository;
import com.example.SpringBootOneToOne.dao.PersonRepository;
import com.example.SpringBootOneToOne.model.AdharCard;
import com.example.SpringBootOneToOne.model.Person;

@Service
public class ServiceImpl implements Services {

	@Autowired
	private PersonRepository personRepo;
	
	@Autowired
	private JavaMailSender mailSender;
	
	
	@Autowired
	private AdharCardRepository adharRepo;

	@Override
	public String savePersonData(Person person) {
		System.out.println("MSG : we are in save method in service layer");
//		System.out.println("MSG : Person That retrived service " + person);
		if (person != null) {
//			person.getAdharCard().setDateOfRegister(new Date());//456

			Optional<Person> person2=personRepo.findById(person.getPid());
//			not null
			System.out.println();
			if(person2.isPresent() ) {
				System.out.println("Error : Person Already exist");
				Person person3=person2.get();
				if(!person.equals(person3)){
					personRepo.save(person);
					return "Person Already Exist And it is updated";
				}
				return "Person Already Exist";
			}else {
				personRepo.save(person);
				System.out.println("MSG : we are in save method completed in service layer");
				return "Successfully Saved";
			}
			
		}else {
			System.out.println("Error : Person Value Is Null");
			return "Null Value is Coming";
		}
		

	}

	@Override
	public String deleteAdharOnly(int pid) {
		System.out.println("Debug : deleteAdharOnly Service Method");
		Optional<Person> op=personRepo.findById(pid);
//		
		if(op.isPresent()) {
			System.out.println("Debug : Person Present in If condition");
			Person p=op.get();
			System.out.println("Info : Person That Searched "+p);
			AdharCard a=p.getAdharCard();
			p.setAdharCard(null);
			personRepo.save(p);
			adharRepo.delete(a);
			System.out.println("Info : Succefully updated!!");
			return "Succefully deleted";
			
		}
		System.out.println("Error : Pid Not Found");
		return "Pid not Found";
	}

	@Override
	public String savePerson(Person p) {
		personRepo.save(p);
		return "Successfully Saved";
	}

	@Override
	public List<AdharCard> getAllAdhar() {
		System.out.println("Info : getAllAdhar in service Layer ");
		List<AdharCard> list=adharRepo.findAll();
		return list;
	}

	@Override
	public void sendMail() {
		
		SimpleMailMessage msg=new SimpleMailMessage();
		
		msg.setTo("prathameshkadam50168@gmail.com");
		msg.setSubject("Regarding Registration");
		msg.setText("You are registred successfully");
		
		mailSender.send(msg);
		
	}
	
	

}
