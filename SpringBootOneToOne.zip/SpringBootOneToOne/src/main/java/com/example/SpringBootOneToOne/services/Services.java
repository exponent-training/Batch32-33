package com.example.SpringBootOneToOne.services;

import java.util.List;

import com.example.SpringBootOneToOne.model.AdharCard;
import com.example.SpringBootOneToOne.model.Person;

public interface Services {
	
	String savePersonData(Person person);
	
	String deleteAdharOnly(int pid);
	
	String savePerson(Person p);
	
	List<AdharCard> getAllAdhar();
	
	void sendMail();
	
	

}
