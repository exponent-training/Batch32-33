package com.example.SpringBootOneToOne.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class AdharCard {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="adharCard_id")
	public int aid;
	
	@Column(name="adharCard_name")
	public String aname;
	
//	@Temporal(TemporalType.DATE)
	public LocalDateTime dateOfRegister;

}
