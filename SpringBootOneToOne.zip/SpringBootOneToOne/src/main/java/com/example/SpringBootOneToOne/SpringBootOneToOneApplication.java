package com.example.SpringBootOneToOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOneToOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneToOneApplication.class, args);
		System.out.println("Hello world !!");
	}

}
