package com.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.entity.Doctor;
import com.entity.Pateints;
import com.util.HibernateUtil;

public class ServiceImpl implements Services{
	
	SessionFactory sf=HibernateUtil.getFactory();
	Scanner sc= new Scanner(System.in);

	@Override
	public void addDoctorWithMuliplePateints() {
		
		Session session=sf.openSession();
		
		Doctor d=new Doctor();
		System.out.println("Enter dname : ");
		d.setDname(sc.next());
		
		System.out.println("Enter the number : ");
		int n=sc.nextInt();
		
		List<Pateints> plist= new ArrayList<Pateints>();
		
		for(int i=1;i<=n;i++) {
			Pateints p=new Pateints();
			
			System.out.println("Enter pname : ");
			p.setPname(sc.next());
			
			p.setDoctor(d);
			
			plist.add(p);
		}
		
		d.setPlist(plist);
		session.persist(d);
		session.beginTransaction().commit();
		
	}

	@Override
	public void addPateintWithDoctor() {
		
		Session session=sf.openSession();
		
		Pateints p=new Pateints();
		System.out.println("Enter pname : ");
		p.setPname(sc.next());
		
		System.out.println("Enter did : ");
		int did=sc.nextInt();
		
		Doctor d=session.get(Doctor.class, did);
		
		if(d!=null) {
			p.setDoctor(d);
			d.getPlist().add(p);
			
			session.saveOrUpdate(d);
			session.beginTransaction().commit();
		}else {
			System.out.println("Invalid id !!");
			addPateintWithDoctor();
		}
		
	}

	@Override
	public void getDoctorWithAllPateints() {
		
		
	}

	@Override
	public void getPateintsWithDoctor() {
		
		
	}

	@Override
	public void updatePateintsUsingDid() {
		
		
		
	}

	@Override
	public void deletePateintOnly() {
		
		Session session=sf.openSession();
		System.out.println("Enter pid : ");
		Pateints p=session.get(Pateints.class, sc.nextInt());
		
		Doctor d=p.getDoctor();
		d.getPlist().remove(p);
		p.setDoctor(null);
		
		session.update(d);
		session.delete(p);
		session.beginTransaction().commit();
		
	}

	@Override
	public void deleteDoctorOnly() {
		
		Session session=sf.openSession();
		System.out.println("Enter did : ");
		Doctor d=session.get(Doctor.class, sc.nextInt());
		
		List<Pateints> plist=d.getPlist();
		
		for(Pateints p:plist) {
			p.setDoctor(null);
		}
		
		d.setPlist(null);
		
		session.update(d);
		session.delete(d);
		session.beginTransaction().commit();
		
	}

}
