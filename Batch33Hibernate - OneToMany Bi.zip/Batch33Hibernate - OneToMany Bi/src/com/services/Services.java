package com.services;

public interface Services {
	
	void addDoctorWithMuliplePateints();
	
	void addPateintWithDoctor();
	
	void getDoctorWithAllPateints();
	
	void getPateintsWithDoctor();
	
	void updatePateintsUsingDid();
	
	void deletePateintOnly();
	
	void deleteDoctorOnly();
	
//	void 

}
