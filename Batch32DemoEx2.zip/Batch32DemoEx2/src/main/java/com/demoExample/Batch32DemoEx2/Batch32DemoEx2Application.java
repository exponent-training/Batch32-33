package com.demoExample.Batch32DemoEx2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch32DemoEx2Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch32DemoEx2Application.class, args);
		
		System.out.println("Hello world");
	}

}
