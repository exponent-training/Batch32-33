package com.demoExample.Batch32DemoEx2.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demoExample.Batch32DemoEx2.model.Student;

@Repository
public class DaoImpl implements DaoMethods{
	
	@Autowired
	private SessionFactory sf;

	@Override
	public void addStudent(Student s) {
		
		System.out.println("Dao Layer");
		
		Session session=sf.openSession();
		
		session.save(s);
		session.beginTransaction().commit();
		
	}
	
	

}
