package com.demoExample.Batch32DemoEx2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demoExample.Batch32DemoEx2.dao.DaoMethods;
import com.demoExample.Batch32DemoEx2.model.Student;

@Service
public class ServiceImpl implements Services {
	
	@Autowired
	private DaoMethods dao;

	@Override
	public void registerStudent(Student s) {
		System.out.println("Service layer");
		
		dao.addStudent(s);
	}
	

}
