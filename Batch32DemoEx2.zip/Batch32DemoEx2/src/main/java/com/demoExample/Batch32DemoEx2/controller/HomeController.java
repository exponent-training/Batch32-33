package com.demoExample.Batch32DemoEx2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demoExample.Batch32DemoEx2.model.Student;
import com.demoExample.Batch32DemoEx2.service.Services;

@Controller
public class HomeController {
	
	@Autowired
	private Services ser;
	
	@RequestMapping(value="/")
	public String start() {
		System.out.println("Start method !!");
		return "index";//view
	}
	
	@RequestMapping(value="/reg")
	public String regsiter(@ModelAttribute Student s) {
		
		System.out.println("Student : "+s);
		ser.registerStudent(s);
		
		return "success";
		
	}

}
