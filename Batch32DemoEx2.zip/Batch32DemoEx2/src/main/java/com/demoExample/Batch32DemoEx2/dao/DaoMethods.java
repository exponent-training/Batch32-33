package com.demoExample.Batch32DemoEx2.dao;

import com.demoExample.Batch32DemoEx2.model.Student;

public interface DaoMethods {
	
	void addStudent(Student s);

}
