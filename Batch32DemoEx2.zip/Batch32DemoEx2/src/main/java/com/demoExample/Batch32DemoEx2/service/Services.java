package com.demoExample.Batch32DemoEx2.service;

import com.demoExample.Batch32DemoEx2.model.Student;

public interface Services {
	
	void registerStudent(Student s);

}
