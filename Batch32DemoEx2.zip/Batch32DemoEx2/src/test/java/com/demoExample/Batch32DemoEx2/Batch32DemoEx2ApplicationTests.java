package com.demoExample.Batch32DemoEx2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch32DemoEx2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
