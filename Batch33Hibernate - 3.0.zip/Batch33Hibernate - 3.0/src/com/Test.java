package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
	
	public static void main(String[] args) {
		
		Student s= new Student();
		s.setSid(16);
		s.setSname("dfgj");
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		
		Session session=sf.openSession();
		
		int id=(int)session.save(s);//serliasbel int
//		session.persist(s);//void
		
//		session.update(s);
//		session.saveOrUpdate(s);
//		session.delete(s);
		session.beginTransaction().commit();
		
//		System.out.println(id);
		
		
		
	}

}
