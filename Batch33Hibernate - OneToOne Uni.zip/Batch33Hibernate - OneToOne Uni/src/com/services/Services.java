package com.services;

public interface Services {
	
	void addStudentAndAddress();
	
	void displaySingleStudentAndAddress();
	
	void displayAllStudentWithAddress();
	
	void updateStudentAndAddress();
	
	void deleteStudentAndAddress();
	
	void deleteAddressOnly();

}
