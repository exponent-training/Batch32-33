package com.mvc.dao;

import java.util.List;

import com.mvc.model.Student;

public interface DaoMethods {
	
	void addStudentData(Student s);
	
	List<Student> getAllStudentData();
	
	void deleteStudentData(int id);

}
