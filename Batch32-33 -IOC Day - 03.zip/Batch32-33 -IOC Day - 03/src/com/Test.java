package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	
	
	public static void main(String[] args) {
		
		ApplicationContext apc=new ClassPathXmlApplicationContext("NewFile.xml");
		
//		Course c=apc.getBean("c",Course.class);
//		System.out.println(c.hashCode());
//		
//		Course c1=apc.getBean("c",Course.class);
//		System.out.println(c1.hashCode());
		
		
		Faculty f=apc.getBean("f",Faculty.class);
		System.out.println(f.hashCode());//1
		System.out.println(f.getCourse().hashCode());//2
		
		System.out.println("----------------------------------------");
		
		Faculty f1=apc.getBean("f",Faculty.class);
		System.out.println(f1.hashCode());//1
		System.out.println(f1.getCourse().hashCode());//3
		
		
	}

}
