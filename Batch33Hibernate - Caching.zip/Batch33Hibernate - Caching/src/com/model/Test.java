package com.model;

import javax.persistence.Cache;

import org.hibernate.Session;
import org.hibernate.SessionFactory;


import javassist.expr.Instanceof;

public class Test {
	
	
	public static void main(String[] args) {
		
		SessionFactory sf=HibernateUtil.getFactory();
		
		Session session=sf.openSession();
		Session session2=sf.openSession();
		
//		Student s= new Student(11,"Prasad");
//		
		
//		Employee e= new Employee();
//		e.setSname("fghj");
//		session.save(e);
//		session.beginTransaction().commit();
		
//		Instanceof >> GetConstor >> default
		
		Student s=session.get(Student.class, 2);//1
		System.out.println(s);
		
		Employee e=session.get(Employee.class, 2);//2
		System.out.println(e);
		
//		session.clear();
//		session.evict(s);
		
		Cache cache=sf.getCache();
//		cache.evictAll();//clear()
		cache.evict(Student.class);
		
		Student s1=session2.get(Student.class, 2);//1
		System.out.println(s1);
		
		Employee e1=session2.get(Employee.class, 2);//2
		System.out.println(e1);
	
		
		
	}

}
