package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
	
	public static void main(String[] args) {
		
		SessionFactory sf=HibernateUtil.getFactory();
		
		Session session=sf.openSession();
		
		Employee e= new Employee();
		e.setEid(1);
		e.setEname("klghj");
//		e.setMarks(45);

		
//		insert into employee(ename) values(?)
		
//		int eid=(int)session.save(e);
		session.saveOrUpdate(e);
		session.beginTransaction().commit();
		
//		System.out.println(eid);
//		System.out.println(cid);
		
//		intial >> 100   increament >> 50  >> Sequence
		
		
	}

}
