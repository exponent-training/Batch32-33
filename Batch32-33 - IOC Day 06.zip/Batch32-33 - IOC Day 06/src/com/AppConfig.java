package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
//@Component
public class AppConfig {
	
	@Bean(name="stu")
	@Scope(value = "prototype")
	public Student student() {
		
		Student s= new Student(11,"sdfg");
//		s.setSid(11);
//		s.setSname("abc");
		
		return s;
	}
	
	
	@Bean
	public College college() {
		
		College c= new College();
		c.setCid(101);
		c.setCname("Pccoe");
//		c.setS(student());
		
		return c;
	}
	
	
	@Bean(name="stu1")
	@Scope(value = "prototype")
	public Student student1() {
		
		Student s= new Student();
		s.setSid(12);
		s.setSname("pqr");
		
		return s;
	}
	
	
}
