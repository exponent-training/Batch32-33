package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
	
	public static void main(String[] args) {
		
		Resource resource=new ClassPathResource("NewFile.xml");
		
		//IOC - 2 (beans,core,context,expression)
		//Container : Read,bean configuration, create bean ,bean life cycle,distory
		
		//BeanFactory(I) (Core)
		//XmlBeanFactory(C)
		//Can't read xml file directly
		//only xml configuration
		//Deprecated
		//lazy loading
		//getBean() then bean created 
		
		//ApplicationContext(I) (J2EE)
		//ClassPathXMLApplicationContext
		//directly read xml
		//Annotation also supported
		//New Concept
		//internally calls Bean Factory
		//Egar loading
		//when it read file
		
		
		BeanFactory bean=new XmlBeanFactory(resource);//Deprecated
		
		System.out.println("-----------------------------------------");
//		MySql m=(MySql) bean.getBean("m");//Object
//		m.m1();
		System.out.println("-----------------------------------------");
//		Oracle o=(Oracle) bean.getBean("o");
//		o.m1();
		
	}

}
