package com;

public class MySql {
	
	public MySql() {
		System.out.println("MySql Constructor");
	}
	
	public void m1() {
		System.out.println("MySQL Method");
	}

}
