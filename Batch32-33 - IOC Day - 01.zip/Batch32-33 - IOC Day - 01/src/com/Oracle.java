package com;

public class Oracle {
	
	public Oracle() {
		System.out.println("Orcale Constructor");
	}
	
	public void m1() {
		System.out.println("Oracle Method");
	}

}
