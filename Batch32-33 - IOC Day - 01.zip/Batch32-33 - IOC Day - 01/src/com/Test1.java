package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test1 {
	
	public static void main(String[] args) {
		
		//J2EE
		ApplicationContext apc=new ClassPathXmlApplicationContext("NewFile.xml");
		
		System.out.println("--------------------------");
//		MySql m=(MySql) apc.getBean("m");
//		m.m1();
		
		
	}

}
