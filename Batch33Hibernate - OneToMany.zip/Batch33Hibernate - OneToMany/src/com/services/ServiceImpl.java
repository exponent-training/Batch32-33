package com.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.entity.Student;
import com.entity.Subject;
import com.util.HibernateUtil;

public class ServiceImpl implements Services {

	Scanner sc = new Scanner(System.in);
	SessionFactory sf = HibernateUtil.getFactory();

	@Override
	public void addStudentWithMultipleSubject() {

		Session session = sf.openSession();

		Student s = new Student();
		System.out.println("Enter Sname : ");
		s.setSname(sc.next());

		List<Subject> sublist = new ArrayList<Subject>();

		System.out.println("How Subject u want to add : ");
		int n = sc.nextInt();// 5

		for (int i = 1; i <= n; i++) {

			Subject sub = new Subject();
			System.out.println("Enter SubName : ");
			sub.setSubName(sc.next());

			sublist.add(sub);

		}

		s.setSubList(sublist);

		session.save(s);
		session.beginTransaction().commit();

	}

	@Override
	public void getStudentWithMultipleSubject() {
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		System.out.println(s);
	}

	@Override
	public void updateStudent() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateSubjectUsingSid() {
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		List<Subject> subList=s.getSubList();
		
		System.out.println(subList);
		System.out.println("Enter subId : ");
		int subId=sc.nextInt();
		
		for(Subject sub:subList) {
			
			if(sub.getSubId()==subId) {
				System.out.println("Enter subName : ");
				sub.setSubName(sc.next());
				session.update(s);
				session.beginTransaction().commit();
			}
			
		}
		
	}

	@Override
	public void deleteStudentWithMultipleSubject() {
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());
		
		

	}

	@Override
	public void deleteSubjectOnly() {
		
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());
		
		List<Subject> subList=s.getSubList();
		
		System.out.println(subList);
		
		System.out.println("Enter subId : ");
		int subId=sc.nextInt();
		
		for(Subject sub:subList) {
			if(sub.getSubId()==subId) {
				
				subList.remove(sub);
				session.update(s);
				session.delete(sub);
				session.beginTransaction().commit();
				
//				1 break 3
				break;
				
			}
			
		}

	}

	@Override
	public void deleteStudentOnly() {
		
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());
		
		s.setSubList(null);
		
		session.update(s);
		session.delete(s);
		session.beginTransaction().commit();
		

	}

	@Override
	public void addExistingSubjectToExistingStudent() {
		
		
		
	}

}
