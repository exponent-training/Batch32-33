package com.services;

public interface Services {
	
	void addStudentWithMultipleSubject();
	
	void getStudentWithMultipleSubject();
	
	void updateStudent();
	
	void updateSubjectUsingSid();
	
	void deleteStudentWithMultipleSubject();
	
	void deleteSubjectOnly();
	
	void deleteStudentOnly();
	
	void addExistingSubjectToExistingStudent();

}
