package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
	
	public static void main(String[] args) {
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
//		Session session=sf.openSession();
//		Session session1=sf.openSession();
//		
//		System.out.println(session.hashCode());
//		System.out.println(session1.hashCode());
		
		
		Session session2=sf.getCurrentSession();
		System.out.println(session2.hashCode());
		
//		session2.close();
		
		Session session3=sf.getCurrentSession();
		System.out.println(session3.hashCode());
		
		
//		Student s= new Student();
//		s.setSid(13);
//		s.setSname("Pqr");
//		
//		session.save(s);
//		session.beginTransaction().commit();
		
//		Student s=session.get(Student.class, 15);
////		System.out.println(s);
//		System.out.println(s.getSid());//proxy >> 15
//		System.out.println(s.getSname());
		
//		proxy >> Lazy loading
		
//		get() egar loading
//		load() lazy loading
		
	}

}
